Voices For The 22 — Talent Participation Kit
Version 1.0 · Updated November 19, 2026

Contents
  voices-talent-participation-brief.pdf   Initiative overview and the request (2 pages)
  voices-recording-guide.pdf              One-page recording reference
  voices-participation-release.pdf        Proposed limited-use release — v0.1-draft (DRAFT: pending founder and legal review; not for signature)
  logos/for-the-22-logo.png               Official For The 22 logo (use on light backgrounds)
  logos/for-the-22-logo-white.png         Official For The 22 logo, white (use on dark backgrounds)

Please use the logos as provided — do not alter, recolor or recreate them.

Talent portal: https://forthe22.org/voices/talent
Contact: Cody Hitson, Founder | For The 22 — cody@forthe22.org

Because 22 ≠ 0.
