﻿FOR THE 22 — OFFICIAL MEDIA KIT
For Those Who Serve. For What Comes Next.

For The 22 connects veterans, first responders, and their families with trusted resources—and mobilizes communities through campaigns that support the organizations serving them.

MEDIA CONTACT
Cody Hitson, Founder — cody@forthe22.org
Newsroom (latest figures, coverage, story ideas): https://forthe22.org/press
One-page fact sheet: https://forthe22.org/press/fact-sheet
Figures change over time; please confirm current numbers on the newsroom page before publishing.

ON-AIR INTRODUCTION
Cody Hitson is a Navy veteran and former combat journalist who founded For The 22 to connect veterans, first responders, and their families with trusted resources—and to rally communities behind the organizations serving them.

SHORT BIO (~50 words)
Cody Hitson is a Navy veteran, husband, and father who served seven years on active duty as a Mass Communication Specialist, including a 2011 deployment to Afghanistan as a combat journalist. He founded For The 22 to help veterans and first responders find trusted resources—and to mobilize communities behind the organizations serving them.

FULL BIO (~150 words)
Cody Hitson is a Navy veteran, husband, father, and endurance athlete who spent seven years on active duty as a Mass Communication Specialist, deploying to Afghanistan in 2011 in support of Operation Enduring Freedom as a combat journalist. After returning home, he spent years learning to function without dealing with what was underneath—a season that included major back surgery in 2016 and no clear sense of what came next. A 2023 retreat with the Mighty Oaks Warrior Program became a turning point, redirecting his recovery around faith, responsibility, and purpose.

Cody founded For The 22 to make that search easier for the next person: a directory of established programs, services, and communities serving veterans, first responders, and their families—paired with campaigns that mobilize communities and raise direct support for confirmed beneficiary organizations. He was featured as the VA's #VeteranOfTheDay.

PHOTOS — USAGE
Free to use in editorial coverage of For The 22 and Cody Hitson. Please include the credit listed with each photo. Not for advertising or endorsement use.

photos/cody-hitson-founder-portrait.jpg
  Cody Hitson, founder of For The 22, during RuckUp22 Huntsville, October 24, 2026.
  Credit: Courtesy of For The 22

photos/cody-hitson-ruckup22-finish.jpg
  Cody Hitson with his 22-mile coin after completing the 11th Annual RuckUp22 in Huntsville, Alabama.
  Credit: Courtesy of For The 22

photos/cody-hitson-afghanistan-2011.jpg
  PO2 Cody Hitson reporting as a combat journalist in Afghanistan, 2011.
  Credit: AFN Afghanistan / U.S. Department of Defense

photos/cody-hitson-navy-service.jpg
  Cody Hitson on active duty as a U.S. Navy Mass Communication Specialist.
  Credit: Courtesy of Cody Hitson

LOGOS
logos/for-the-22-logo.png ............. For The 22 mark, light backgrounds
logos/for-the-22-logo-white.png ....... For The 22 mark, dark backgrounds
logos/tri-for-the-22-logo.png ......... Tri For The 22 campaign mark, light backgrounds
logos/tri-for-the-22-logo-white.png ... Tri For The 22 campaign mark, dark backgrounds
Please don't recolor, stretch, or crop the marks.

STATUS
For The 22 is not a registered nonprofit and does not receive charitable contributions. Donations go directly to the beneficiary organization each donor selects.
For The 22 is an independent initiative and is not sponsored, endorsed, operated by, or affiliated with any employer or government entity. No government authority, resources, or nonpublic information are used in its operation.
