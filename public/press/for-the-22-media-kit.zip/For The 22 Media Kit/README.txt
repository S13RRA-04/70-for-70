﻿FOR THE 22 — OFFICIAL MEDIA KIT
For Those Who Serve. For What Comes Next.

For The 22 connects veterans, first responders, and their families with trusted resources—and mobilizes communities through campaigns that support the organizations serving them.

MEDIA CONTACT
Cody Hitson, Founder — cody@forthe22.org
Newsroom (latest figures, coverage, story ideas): https://forthe22.org/press
One-page fact sheet: https://forthe22.org/press/fact-sheet
Figures change over time; please confirm current numbers on the newsroom page before publishing.

ON-AIR INTRODUCTION
Cody Hitson is a Navy veteran and former combat journalist who founded For The 22 to connect veterans, first responders, and their families with trusted resources—and to rally communities behind the organizations serving them.

SHORT BIO (~50 words)
Cody Hitson is a Navy veteran, husband, and father who served seven years on active duty as a Mass Communication Specialist, including a 2011 deployment to Afghanistan as a combat journalist. He founded For The 22 to help veterans and first responders find trusted resources—and to mobilize communities behind the organizations serving them.

FULL BIO (~150 words)
Cody Hitson is a Navy veteran, husband, father, and endurance athlete who spent seven years on active duty as a Mass Communication Specialist, deploying to Afghanistan in 2011 in support of Operation Enduring Freedom as a combat journalist. After returning home, he spent years learning to function without dealing with what was underneath—a season that included major back surgery in 2016 and no clear sense of what came next. A 2023 retreat with the Mighty Oaks Warrior Program became a turning point, redirecting his recovery around faith, responsibility, and purpose.

Cody founded For The 22 to make that search easier for the next person: a directory of established programs, services, and communities serving veterans, first responders, and their families—paired with campaigns that mobilize communities and raise direct support for confirmed beneficiary organizations. He was featured as the VA's #VeteranOfTheDay.

PHOTOS — USAGE
Free to use in editorial coverage of For The 22 and Cody Hitson. Please include the credit listed with each photo. Not for advertising or endorsement use.

photos/cody-hitson-headshot.jpg
  Cody Hitson, Navy veteran and founder of For The 22.
  Credit: Courtesy of Cody Hitson

photos/cody-hitson-founder-portrait.jpg
  Cody Hitson, founder of For The 22, during RuckUp22 Huntsville, October 24, 2026.
  Credit: Courtesy of For The 22

photos/cody-hitson-ruckup22-finish.jpg
  Cody Hitson with his 22-mile coin after completing the 11th Annual RuckUp22 in Huntsville, Alabama.
  Credit: Courtesy of For The 22

photos/cody-hitson-afghanistan-2011.jpg
  PO2 Cody Hitson reporting as a combat journalist in Afghanistan, 2011.
  Credit: AFN Afghanistan / U.S. Department of Defense

photos/cody-hitson-afghanistan-deployment.jpg
  Cody Hitson deployed to Afghanistan in support of Operation Enduring Freedom, 2011.
  Credit: Courtesy of Cody Hitson

photos/cody-hitson-navy-service.jpg
  Cody Hitson on active duty as a U.S. Navy Mass Communication Specialist.
  Credit: Courtesy of Cody Hitson

LOGOS
logos/for-the-22-logo.png ............. For The 22 mark, light backgrounds
logos/for-the-22-logo-white.png ....... For The 22 mark, dark backgrounds
logos/tri-for-the-22-logo.png ......... Tri For The 22 campaign mark, light backgrounds
logos/tri-for-the-22-logo-white.png ... Tri For The 22 campaign mark, dark backgrounds
Please don't recolor, stretch, or crop the marks.

APPROVED QUOTES
Approved by each speaker for use as written.

"As I look back on my transition out of the Marine Corps, I know that I would not have made it without a community of faith and those who were willing to step into my life during some of my darkest days. While it may have looked like I was trying to burn down everything I cared about, it was the authentic relationships with those who cared about me and my family that helped us get right with each other, right with God, and find renewed purpose after military service. What I understand now, in light of my own transition and the transition stories of thousands of men and women who have come through Mighty Oaks Programs, is that restoration and renewed purpose happen when the community of faith steps into the darkness so many are living in and shines the light of hope found in a relationship with our Creator."
  — Jeremy Stalnecker, CEO and U.S. Marine Corps veteran, Mighty Oaks Foundation

"Adaptive sports has been life-changing for so many of us. Honestly, many of us might not be here today without the opportunities, support, and community these programs provide. Our ability to help provide VAU Sports grants towards travel to events and equipment needed to participate can be the decisive point for many veterans to continue to move forward with their disabilities."
  — James Howard, President, Veterans and Athletes United

ABOUT THE BENEFICIARIES
Mighty Oaks Foundation — https://www.mightyoaksprograms.org/
A Christian faith-based 501(c)(3) nonprofit, founded in 2010 and based in Montgomery, Texas, running recovery and resiliency programs for military and first responder communities and their spouses, at no cost to participants. EIN 45-3159170.
Source for the figures below: Mighty Oaks 2025 Supporter Annual Report (January 1 – December 31, 2025). Please attribute them to Mighty Oaks.
  • 1,085 graduates from 42 recovery programs in 2025: 761 military veterans and service members, 287 first responders (police, fire, and EMS), and 37 Special Immigrant Visa recipients
  • $4,240,470 spent on programs in 2025 — an average of $3,500 per participant, covering travel, lodging, meals, materials, and aftercare
  • 2,332 program applications received in 2025, with 2,025 applicants on the waiting list
  • 93 resiliency events in 2025, reaching roughly 80,000 attendees
  • 79 local Outposts providing aftercare to an average of 430 people
  • 74% of 2025 expenses went to program services, 14% to fundraising, and 12% to management and general
Mighty Oaks media contact: Michael Cameron, Chief Marketing Officer — michael@mightyoaksprograms.org · 832-422-7361

STATUS
For The 22 is not a registered nonprofit and does not receive charitable contributions. Donations go directly to the beneficiary organization each donor selects.
For The 22 is an independent initiative and is not sponsored, endorsed, operated by, or affiliated with any employer or government entity. No government authority, resources, or nonpublic information are used in its operation.
